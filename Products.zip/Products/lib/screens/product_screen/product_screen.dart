import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:products/screens/product_screen/controller/controller.dart';
import '../../components/customCard.dart';

class ProductScreen extends StatelessWidget{
  const ProductScreen({super.key});

  @override
  Widget build(BuildContext context) {
  //final ProductController controller=Get.put(ProductController());
    return Scaffold(
    appBar:AppBar(title:Text("Products",style: TextStyle(color:Colors.brown,fontSize: 30,fontWeight: FontWeight.w500),),
    backgroundColor: Colors.white,),
    body:
    GetBuilder<ProductController>(
      builder: (controller) {
        return
          GridView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.all(10),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: .6,
            mainAxisSpacing: 15,
            crossAxisSpacing: 15,
          ),
          itemCount: controller.prod.length,
          itemBuilder: (BuildContext context, int index) {
            return customCard(
              image:controller.prod[index].images?[1]??"",
              name: controller.prod[index].title??"",
              price:controller.prod[index].price??"",
              //  image:"",
              //  name: "Iphone",
              //  price:"5",
            );},
        );
      },
     ),
    );
  }

}

